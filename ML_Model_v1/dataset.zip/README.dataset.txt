# RRD > 2023-06-05 3:46pm
https://universe.roboflow.com/ilman-gifari-utdmy/rrd-waisv

Provided by a Roboflow user
License: CC BY 4.0

